package main

//version 1.0

import (
	"errors"
	"fmt"
	"math/rand"
	"os"
	"strconv"
	"strings"
	"time"
	//"bufio"
	//"os"
)

type Grid struct {
	height, width int
	grid          []byte
}

func (g Grid) String() string {
	return string(g.grid)
}

func NewGrid(x, y int) Grid {
	wth := 2*x + 2 // +2 for right column + '\n'
	hgt := 2*y + 1 // +1 for bottom row

	g := make([]byte, wth*hgt)

	for i := 0; i < hgt; i += 2 {
		row0 := i * wth
		row1 := (i + 1) * wth
		for j := 0; j < wth-2; j += 2 {
			g[row0+j], g[row0+j+1] = '+', '-'
			if row1+j+1 <= wth*hgt {
				g[row1+j], g[row1+j+1] = '|', ' '
			}
		}
		g[row0+wth-2], g[row0+wth-1] = '+', '\n'
		if row1+wth < wth*hgt {
			g[row1+wth-2], g[row1+wth-1] = '|', '\n'
		}
	}

	return Grid{
		height: y,
		width:  x,
		grid:   g,
	}
}

func (g Grid) Set(c byte, x, y int) error {
	idx, err := g.cellAt(x, y)
	if err != nil {
		return err
	}
	g.grid[idx] = c
	return nil
}

func (g Grid) cellAt(x, y int) (int, error) {
	woff := g.width*2 + 2 // width offset
	foff := (y*2+1)*woff + x*2 + 1

	if foff > len(g.grid) {
		return 0, errors.New("out of range")
	}

	return (y*2+1)*woff + x*2 + 1, nil
}

func (g Grid) Draw() {
	//fmt.Print("\033[H\033[2J")         // Clear screen
	fmt.Print("\x0c", g, "\n")         // Print frame
	time.Sleep(250 * time.Millisecond) // Delay between frames

}

func max(is ...int) int {
	if len(is) == 0 {
		return 0
	}

	m := is[0]
	for _, v := range is[1:] {
		if v > m {
			m = v
		}
	}
	return m
}

// func name(insert type) returntype
//CTM6
func getSeed() int {
	fmt.Println("Please enter the seed: ")
	var tempSeed string
	fmt.Scanln(&tempSeed)
	numberSeed, _ := (strconv.Atoi(tempSeed))
	return numberSeed
}

//CTM7
func checkSeed(tempSeed string) int {
	presetSeed := 0
	numberSeed, _ := (strconv.Atoi(tempSeed))
	if (numberSeed >= -2147483648) && (numberSeed <= 2147483647) {
		presetSeed = numberSeed
	}
	return presetSeed
}

func randomPosition(maxValue int) int {

	randNum := (rand.Intn(maxValue))
	return randNum
}

// CTM1.2
func drawGrid(sX int, sY int, gX int, gY int, tgX int, tgY int, tX int, tY int, g Grid, treasureCollected bool) {

	//draw ghost
	g.Set('g', gX, gY)
	//draw treasure goblin
	g.Set('t', tgX, tgY)
	//draw treasure
	if treasureCollected == false {
		g.Set('x', tX, tY)
	}
	//draw student
	g.Set('s', sX, sY)
	g.Draw()
}

//CTM2
func getMove() string {
	fmt.Print("Move: ") //Print function is used to display output in same line
	var move string
	fmt.Scanln(&move)
	return move
}

//CTM4 and //CTM5
func checkMove(move string, studentX int, studentY int) (int, int) {
	switch move {
	case "n":
		studentY++
		if studentY < 0 {
			fmt.Println("You are unable to move in this direction!")
			studentY = 0
		}
	case "N":
		studentY++
		if studentY < 0 {
			fmt.Println("You are unable to move in this direction!")
			studentY = 0
		}
	case "s":
		studentY--
		if studentY > 9 {
			fmt.Println("You are unable to move in this direction!")
			studentY = 9
		}
	case "S":
		studentY--
		if studentY > 9 {
			fmt.Println("You are unable to move in this direction!")
			studentY = 9
		}
	case "e":
		studentX++
		if studentX > 9 {
			fmt.Println("You are unable to move in this direction!")
			studentX = 9
		}
	case "E":
		studentX++
		if studentX > 9 {
			fmt.Println("You are unable to move in this direction!")
			studentX = 9
		}
	case "w":
		studentX++
		if studentX < 0 {
			fmt.Println("You are unable to move in this direction!")
			studentX = 0
		}
	case "W":
		studentX++
		if studentX < 0 {
			fmt.Println("You are unable to move in this direction!")
			studentX = 0
		}
	default:
		fmt.Println("Please enter a valid move - N, n, S, s, E, e, W or w!")
	}

	return studentX, studentY
}

func moveGhost(ghostX int, ghostY int, randGhost int) (int, int) {
	//Move ghost in that direction
	fmt.Println(randGhost)
	switch randGhost {
	//moves Ghost north
	case 0:
		ghostY--
		if ghostY < 0 {
			fmt.Println("The ghost has bumped into the wall!")
			ghostY = 0
		}
	//moves Ghost south
	case 1:
		ghostY++
		if ghostY > 9 {
			fmt.Println("The ghost has bumped into the wall!")
			ghostY = 9
		}
	//moves Ghost east
	case 2:
		ghostX++
		if ghostX > 9 {
			fmt.Println("The ghost has bumped into the wall!")
			ghostX = 9
		}
	//moves Ghost west
	case 3:
		ghostX--
		if ghostX < 0 {
			fmt.Println("The ghost has bumped into the wall!")
			ghostX = 0
		}
	}
	return ghostX, ghostY
}

func checkTreasureGoblinLocation(studentX int, studentY int, treasureGoblinX int, treasureGoblinY int) int {
	nextDoorGoblin := 0
	if (studentX+1 == treasureGoblinX) && (studentY == treasureGoblinY) {
		nextDoorGoblin = 1
	} else if (studentX-1 == treasureGoblinX) && (studentY == treasureGoblinY) {
		nextDoorGoblin = 1
	} else if (studentY-1 == treasureGoblinY) && (studentX == treasureGoblinX) {
		nextDoorGoblin = 1
	} else if (studentY+1 == treasureGoblinY) && (studentX == treasureGoblinX) {
		nextDoorGoblin = 1
	}
	return nextDoorGoblin
}

func checkGhostLocation(studentX int, studentY int, ghostX int, ghostY int) int {
	nextDoorGhost := 0
	if (studentX+1 == ghostX) && (studentY == ghostY) {
		nextDoorGhost = 1
	} else if (studentX-1 == ghostX) && (studentY == ghostY) {
		nextDoorGhost = 1
	} else if (studentY-1 == ghostY) && (studentX == ghostX) {
		nextDoorGhost = 1
	} else if (studentY+1 == ghostY) && (studentX == ghostX) {
		nextDoorGhost = 1
	}
	return nextDoorGhost
}

func checkGameStatus(studentX int, studentY int, treasureGoblinX int, treasureGoblinY int, treasureCollected bool) bool {
	playingGame := true
	if studentX == treasureGoblinX && studentY == treasureGoblinY {
		if treasureCollected == true {
			fmt.Println("You win!")
			playingGame = false
		} else {
			fmt.Println("You Loose!")
			playingGame = false
		}
	}
	return playingGame
}

func checkTreasureCollect(studentX int, studentY int, treasureX int, treasureY int) bool {
	var treasureCollected bool
	if (studentX == treasureX) && (studentY == treasureY) {
		treasureCollected = true
		fmt.Println("Treasure Collected - Head to the Treasure Goblin!")
	}
	return treasureCollected
}

func main() {
	const (
		w = 10
		h = 10
	)

	studentX := 0
	studentY := 0
	ghostX := 8
	ghostY := 8
	treasureCollected := false
	playingGame := true

	arg := os.Args[1:]
	tempSeed := strings.Join(arg, " ")
	seed := checkSeed(tempSeed)

	var seed64 int64
	seed64 = int64(seed)

	if seed == 0 {
		rand.Seed(time.Now().UTC().UnixNano())
	} else {
		rand.Seed(seed64)
	}

	//CTM1.1
	g := NewGrid(w, h)

	//CTM8.3
	treasureGoblinX := randomPosition(9)
	if treasureGoblinX == 0 {
		treasureGoblinX = randomPosition(9)
	}
	treasureGoblinY := randomPosition(9)

	//CTM9.1a
	treasureX := randomPosition(9)
	if treasureX == 0 {
		treasureX = randomPosition(9)
	}
	treasureY := randomPosition(9)

	drawGrid(studentX, studentY, ghostX, ghostY, treasureGoblinX, treasureGoblinY, treasureX, treasureY, g, treasureCollected)

	for playingGame == true {
		move := getMove()
		studentX, studentY = checkMove(move, studentX, studentY)

		//CTM8.1 - Random Ghost Move
		//CTM8.2 - Ghost Wall Bump
		randGhostMove := randomPosition(4)
		//fmt.Println(ghostX, ghostY)
		ghostX, ghostY = moveGhost(ghostX, ghostY, randGhostMove)
		//fmt.Println(ghostX, ghostY)

		//CTM12 (Missing Requirement
		if treasureCollected == false {
			treasureCollected = checkTreasureCollect(studentX, studentY, treasureX, treasureY)
		}

		//fmt.Println(treasureCollected)

		//CTM9.1 and CTM9.2
		playingGame = checkGameStatus(studentX, studentY, treasureGoblinX, treasureGoblinY, treasureCollected)

		//CTM10
		nextDoorGoblin := checkTreasureGoblinLocation(studentX, studentY, treasureGoblinX, treasureGoblinY)
		if nextDoorGoblin == 1 {
			fmt.Println("Mumbling of Treasure Goblin")
		}

		//CTM11
		nextDoorGhost := checkGhostLocation(studentX, studentY, ghostX, ghostY)
		if nextDoorGhost == 1 {
			fmt.Println("Mumbling of Treasure Goblin")
		}

		g = NewGrid(w, h)
		drawGrid(studentX, studentY, ghostX, ghostY, treasureGoblinX, treasureGoblinY, treasureX, treasureY, g, treasureCollected)
	}
	os.Exit(3)

}
