package main

import (
	"testing"
)

//to test say go test

//example test:
//tests that the average is correct for the test
// func TestCalculateAverage(c *testing.T){
// 	total := 10.5
// 	paperTotal := 2.00

// 	testAverage := calculateAverage (total, paperTotal)

// 	if testAverage != 5.25{
// 		c.Error("Average Calculation is incorrect")
// 	}
// }

// Case 1 CTM7	**
func TestcheckSeedString(t *testing.T) {
	//pre condition
	testSeed := "abc"
	//test
	seed := checkSeed(testSeed)
	//post condition  (assert)
	if seed != 0 {
		t.Error("Does not deal with strings correctly.")
	}
}

// Case 2 CTM7

func TestcheckSeedUpperRange(t *testing.T) {
	//pre condition
	testSeed := "53762537623752635"
	//test
	seed := checkSeed(testSeed)
	//post condition  (assert)

	if seed != 0 {
		t.Error("Int larger than 32int shouldn't be accepted")
	}
}

// Case 3 CTM7

func TesteckSeedLowerRange(t *testing.T) {
	//pre condition
	testSeed := "-43786376287624786"
	//test
	seed := checkSeed(testSeed)
	//post condition  (assert)
	if seed != 0 {
		t.Error("Int smaller than 32int shouldn't be accepted")
	}
}

// Case 4 CTM7

func TestcheckSeedMultipleInputs(t *testing.T) {
	//pre condition
	testSeed := "3754634  44334"
	//test
	seed := checkSeed(testSeed)
	//post condition  (assert)
	if seed != 0 {
		t.Error("Shouldn't accept multiple inputs")
	}
}

// Case 5 CTM6

func TestCheckSeed(t *testing.T) {
	//pre condition
	testSeed := "36783"
	//test
	seed := checkSeed(testSeed)
	//post condition  (assert)
	if seed != 36783 {
		t.Error("Seed wasn't accepted")
	}
}

// Case 6 CTM6

func TestCheckSeedA(t *testing.T) {
	testSeed := "-2147483648"

	seed := checkSeed(testSeed)

	if seed != -2147483648 {
		t.Error("Lower bound wasn't accepted")
	}
}

// Case 7 CTM6

func TestCheckSeedB(t *testing.T) {

	testSeed := "2147483647"

	seed := checkSeed(testSeed)

	if seed != 2147483647 {
		t.Error("Upper bound wasn't accepted")
	}
}

// Case 10 CTM4

func TestCheckMoveLowerN(t *testing.T) {

	studentY := 4
	studentX := 4
	move := "n"

	x, y := checkMove(move, studentX, studentY)

	if y != 3 && x != 4 {
		t.Error("Couldn't move north")
	}

}

// Case 11 CTM4

func TestCheckMoveUpperN(t *testing.T) {

	studentY := 4
	studentX := 4
	move := "N"

	x, y := checkMove(move, studentX, studentY)

	if y != 3 && x != 4 {
		t.Error("Couldn't move north")
	}

}

// Case 12 CTM4

func TestCheckMoveLowerS(t *testing.T) {

	studentY := 4
	studentX := 4
	move := "s"

	x, y := checkMove(move, studentX, studentY)

	if y != 5 && x != 4 {
		t.Error("Couldn't move south")
	}

}

// Case 13 CTM4

func TestCheckMoveUpperS(t *testing.T) {

	studentY := 4
	studentX := 4
	move := "S"

	x, y := checkMove(move, studentX, studentY)

	if y != 5 && x != 4 {
		t.Error("Couldn't move south")
	}

}

// Case 14 CTM4

func TestCheckMoveLowerE(t *testing.T) {

	studentY := 4
	studentX := 4
	move := "e"

	x, y := checkMove(move, studentX, studentY)

	if y != 4 && x != 5 {
		t.Error("Couldn't move east")
	}

}

// Case 15 CTM4

func TestCheckMoveUpperE(t *testing.T) {

	studentY := 4
	studentX := 4
	move := "E"

	x, y := checkMove(move, studentX, studentY)

	if y != 4 && x != 5 {
		t.Error("Couldn't move east")
	}

}

// Case 16 CTM4

func TestCheckMoveLowerW(t *testing.T) {

	studentY := 4
	studentX := 4
	move := "w"

	x, y := checkMove(move, studentX, studentY)

	if y != 4 && x != 3 {
		t.Error("Couldn't move west")
	}

}

// Case 17 CTM4

func TestCheckMoveUpperW(t *testing.T) {

	studentY := 4
	studentX := 4
	move := "W"

	x, y := checkMove(move, studentX, studentY)

	if y != 4 && x != 3 {
		t.Error("Couldn't move west")
	}

}

// Case 19 CTM5

func TestCheckMoveEdgeLowerNorth(t *testing.T) {

	studentY := 0
	studentX := 3
	move := "n"

	x, y := checkMove(move, studentX, studentY)

	if y != 0 && x != 3 {
		t.Error("Couldn't move should be edge case with error message displayed to user")
	}

}

// Case 20 CTM5

func TestCheckMoveEdgeUpperNorth(t *testing.T) {

	studentY := 0
	studentX := 3
	move := "N"

	x, y := checkMove(move, studentX, studentY)

	if y != 0 && x != 3 {
		t.Error("Couldn't move should be edge case with error message displayed to user")
	}

}

// Case 21 CTM5

func TestCheckMoveEdgeLowerSouth(t *testing.T) {

	studentY := 9
	studentX := 3
	move := "s"

	x, y := checkMove(move, studentX, studentY)

	if y != 9 && x != 3 {
		t.Error("Couldn't move should be edge case with error message displayed to user")
	}

}

// Case 22 CTM5

func TestCheckMoveEdgeUpperSouth(t *testing.T) {

	studentY := 9
	studentX := 3
	move := "S"

	x, y := checkMove(move, studentX, studentY)

	if y != 9 && x != 3 {
		t.Error("Couldn't move should be edge case with error message displayed to user")
	}

}

// Case 23 CTM5

func TestCheckMoveEdgeLowerEast(t *testing.T) {

	studentY := 3
	studentX := 9
	move := "e"

	x, y := checkMove(move, studentX, studentY)

	if y != 3 && x != 9 {
		t.Error("Couldn't move should be edge case with error message displayed to user")
	}

}

// Case 24 CTM5

func TestCheckMoveEdgeUpperEast(t *testing.T) {

	studentY := 3
	studentX := 9
	move := "E"

	x, y := checkMove(move, studentX, studentY)

	if y != 3 && x != 9 {
		t.Error("Couldn't move should be edge case with error message displayed to user")
	}

}

// Case 25 CTM5

func TestCheckMoveEdgeLowerWest(t *testing.T) {

	studentY := 3
	studentX := 0
	move := "w"

	x, y := checkMove(move, studentX, studentY)

	if y != 3 && x != 0 {
		t.Error("Couldn't move should be edge case with error message displayed to user")
	}

}

// Case 26 CTM5

func TestCheckMoveEdgeUpperWest(t *testing.T) {

	studentY := 3
	studentX := 0
	move := "W"

	x, y := checkMove(move, studentX, studentY)

	if y != 3 && x != 0 {
		t.Error("Couldn't move should be edge case with error message displayed to user")
	}

}

//case 28
//Ghost on left edge and tries to move north
func GhostEdgeNorth(t *testing.T) {
	ghostX := 0
	ghostY := 3
	move := 0

	x, y := moveGhost(ghostX, ghostY, move)

	if x != 0 && y != 3 {
		t.Error("Does not bump into wall")
	}
}

//case 29
//Ghost on left edge and tries to move south
func GhostEdgeSouth(t *testing.T) {
	ghostX := 9
	ghostY := 3
	move := 1

	x, y := moveGhost(ghostX, ghostY, move)

	if x != 9 && y != 3 {
		t.Error("Does not bump into wall")
	}
}

//case 30
//Ghost on left edge and tries to move east
func GhostEdgeEast(t *testing.T) {
	ghostX := 3
	ghostY := 9
	move := 2

	x, y := moveGhost(ghostX, ghostY, move)

	if x != 3 && y != 9 {
		t.Error("Does not bump into wall")
	}
}

//case 31
//Ghost on left edge and tries to move west
func GhostEdgeWest(t *testing.T) {
	ghostX := 3
	ghostY := 0
	move := 3

	x, y := moveGhost(ghostX, ghostY, move)

	if x != 3 && y != 0 {
		t.Error("Does not bump into wall")
	}
}

//case 33
//User alerted to mumbling of treasure in command line.
func TestMumbing(t *testing.T) {
	studentY := 5
	studentX := 0
	ghostX := 0
	ghostY := 4

	testNDTGoblin := checkTreasureGoblinLocation(studentX, studentY, ghostX, ghostY)

	if testNDTGoblin != 1 {
		t.Error("Does not alert user to mumbling")
	}

}

//Case 34
//User alerted to sound of falling coins in command line.

func TestFallingCoins(t *testing.T) {
	studentY := 5
	studentX := 0
	ghostX := 0
	ghostY := 4

	testNDGhost := checkGhostLocation(studentX, studentY, ghostX, ghostY)

	if testNDGhost != 1 {
		t.Error("Does not alert user to coin falling")
	}

}
